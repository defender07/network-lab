do
you
know me ?
why ?
