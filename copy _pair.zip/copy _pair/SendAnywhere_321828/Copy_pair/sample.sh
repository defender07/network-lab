hello everyone
shilu here
welcome to 
shell script
how are you doing?
